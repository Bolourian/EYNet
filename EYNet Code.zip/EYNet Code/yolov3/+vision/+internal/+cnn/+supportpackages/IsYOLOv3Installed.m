function IsYOLOv3Installed()
% This is an empty bread-crumb function used to determine the location of
% the yolov3 support package.

%   Copyright 2021 The MathWorks, Inc.